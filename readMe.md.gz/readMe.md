Repo URL: https://gitlab2.teleserv.ph/LWC/lwc-batch-uploader.git    
    
Production Server: 119.92.186.151(SANDBOX-PROD) -- cd lwc-batch-uploader.pti.ph
Staging Server: 10.0.0.98 -- when in the server use command : cd /var/www/lwc-batch-uploader
   
Purpose/Objectives:
    The purpose of this app for the client to see the result of their file upload CAN in realtime

Background:
    What LWC Clients does is they upload a file which is called Batch File that contains a Contract Account Number (CAN) to create a ticket in CRM, 
    and the client will download the file for the status of each can if totally created or exists.

    
Project Specs/Details: 
     Upload Batch File: 
            - upload a file which contains fields:
                - sap_mru
                - sap_can
                - sap_name
                - sap_address
                - sap_device_number
                - contact_number
                - concern_type
                - remarks
                - complaint_Source
            - when process the upload file, validates the header, and count are correct.
            - the process of creating ticket will see in real time        
     File Upload List:    
            - filters dates by whole month and show the result of filter and download it.
            
Related Notes:
    APP LOCAL SETUP
        1. clone: git repo
        2. composer install
        3. cp .env.example .env 
        4. run php artisan key generate
        5. set the credentials of hydra
        6. run php artisan websockets:serve --port= or read the documentation of laravel websockets
        https://docs.beyondco.de/laravel-websockets/1.0/getting-started/introduction.html                    
    Staging DB:
        Host : Local
        UN/PW : batch_uploader
        DB NAME : lwc-batch-uploader
    DB Structure:     
        DB Diagram : https://dbdiagram.io/d/5e4dcfcf07a7395d994ddd9d
