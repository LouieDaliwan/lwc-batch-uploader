<?php

namespace App\Listeners;

use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use SocialiteProviders\Teleserv\Events\UserLoggedIn; 

class SynchronizeUserRoles
{
    protected $role_map = [
        'supervisor' => ['ITHEAD', 'JRPMR', 'lwc_supervisor'],
        'client' => ['lwc_client']
    ];
        
    public function handle(UserLoggedIn $event)
    {
        $user = $event->user;
        
        $user->first_name = $event->erm_user->first_name;
        $user->last_name = $event->erm_user->last_name;
        $user->employee_code = $event->erm_user->employee_code;
        $user->save();

        $roles = collect($event->erm_user->roles);
        $this->applyRoleMap($user, $roles);
    }

    public function applyRoleMap($user, $roles)
    {
        
        foreach($this->role_map as $role => $position_codes)
        {        
            if($roles->intersect($position_codes)->isNotEmpty()){
                    $user->assignRole($role);
            }
        }
    }
}
