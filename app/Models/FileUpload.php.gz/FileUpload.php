<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\User;
use App\Models\TicketDataResult;

class FileUpload extends Model
{
    protected $guarded = [];

    
    public function tickets()
    {
     return $this->hasMany(TicketDataResult::class, 'file_upload_id');
    }

    public function user()
    {
     return $this->belongsTo(User::class);
    }
}
