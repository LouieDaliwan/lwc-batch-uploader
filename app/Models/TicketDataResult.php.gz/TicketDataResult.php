<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\FileUpload;

class TicketDataResult extends Model
{
    protected $guarded = [];


    public function fileUpload()
    {
      return  $this->belongsTo(FileUpload::class);
    }
}
