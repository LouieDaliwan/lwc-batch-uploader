<?php

namespace App\Http\Controllers;

use App\Jobs\BatchUploadJob;
use App\Jobs\BatchUpdateResultJob;
use App\Models\FileData;
use App\Models\FileUpload;
use App\Models\TicketDataResult;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\BatchRequest;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Response;
use Mockery\Exception;
use App\User;
use Illuminate\Support\Carbon;
use App\FileValidate;

class BatchController extends Controller
{
    public function index()
    {
        $this->authorize('upload-files');
        return view('batch-upload.index');
    }

    public function store(BatchRequest $request)
    {
        $this->authorize('upload-files');
        $file = request()->file('file');
        $user = auth()->user();
        $username = request('username');

        $auth_user = User::find($user->id);
        if($auth_user->username != $username){
            $auth_user->username = $username;
            $auth_user->save();
        }

        $validate = new FileValidate();

        $validate = $validate->file($file);

        if($validate == 'Passed'){
            $file_upload = FileUpload::create([
                'filename' =>  $file->getClientOriginalName(),
                'uploader_name' => $user->name,
                'status' => 'In Progress',
                'user_id' => $user->id,
            ]);

            $file->move(storage_path('/uploads'), "upload_$file_upload->id.csv");

        
            $this->dispatch(new BatchUploadJob($file_upload, $username));

            return redirect('/batch/file-uploads/'. $file_upload->id);
        } else {
            
            return back()->with('Error', 'Error!, Please check the file content');
        }
               
    }

    public function show($id)
    {
        $this->authorize('upload-files');

        $file_upload = FileUpload::find($id);

        return view('batch-upload.show', compact('file_upload'));
    }

    public function fileUploadLists()
    {
        $this->authorize('upload-files');

        $from = Carbon::parse('first day of this month');
        $to = Carbon::parse('last day of this month');

        return view('batch-upload.list', compact('from', 'to'));
    }

    public function filterFileUploads()
    {
        $from = Carbon::parse(request('from') . ' ' . '00:00:00');
        $to = Carbon::parse(request('to') . ' ' . '23:59:59');


        $files = FileUpload::where('created_at', '>=', $from)
        ->where('created_at', '<=', $to);

        if(!empty(request('uploader')))
        {
            $files = $files->where('uploader_name', 'like',  request('uploader'). '%' );

        }

        return response()->json(['files' => $files->paginate(15)->appends(request()->except('page'))]);
    }

    public function getDate()
    {
        $date = new Carbon(request('from'));

        return response()->json(['to' => $date->lastOfMonth()->format('Y-m-d')]);
    }

    public function fileUploadsResult(Request $request)
    {
        $this->authorize('upload-files');

        $tickets_result = TicketDataResult::where('file_upload_id', request('file_upload_id'))
        ->get();

        return json_encode($tickets_result);
    }

    public function downloadFileUploadResult(Request $request)
    {
        $this->authorize('upload-files');

        $ticket_results = TicketDataResult::where('file_upload_id', request('id'))
        ->get();

        $headers = [
            'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
            'Content-type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename=FileUploadDataResult.csv',
            'Expires' => '0',
            'Pragma' => 'public'
        ];

        $callback = function () use ($ticket_results) {

            $fh = fopen('php://output', 'w');

            fputcsv($fh, [
                'sap_mru',
                'sap_can',
                'sap_name',
                'sap_address',
                'sap_device_number',
                'contact_number',
                'concern_type',
                'remarks',
                'complaint_message',
                'result_message',
                'ticket_id',
            ]);
            foreach ($ticket_results as $ticket_result) {
                fputcsv($fh, [
                    $ticket_result->sap_mru,
                    $ticket_result->sap_can,
                    $ticket_result->sap_name,
                    $ticket_result->sap_address,
                    $ticket_result->sap_device_number,
                    $ticket_result->contact_number,
                    $ticket_result->concern_type,
                    $ticket_result->remarks,
                    $ticket_result->complaint_source,
                    $ticket_result->result_message,
                    $ticket_result->ticket_id,
                ]);
            }
            fclose($fh);
        };
        return Response::stream($callback, 200, $headers);
    }

    public function results(Request $request)
    {
        $this->dispatch(new BatchUpdateResultJob($request['data']));
    }
}
