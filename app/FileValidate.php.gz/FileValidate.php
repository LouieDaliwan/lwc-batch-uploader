<?php


namespace App;


Class FileValidate 
{
    public function file($file)
    {
        $file = fopen($file, 'r');

        $fh = fgetcsv($file);

        $header = [
            'sap_mru', 'sap_can', 'sap_name', 'sap_address', 
            'sap_device number', 'contact_number', 'concern_type', 'remarks', 'complaint_source'
        ];

        $count_error = 0;

        if(count($fh) != 9){
            logger('Failed to validate', $fh);
            return 'Failed';
        } else {
            foreach($fh as $rowHeader){
                if(!in_array($rowHeader, $header)){
                    $count_error++;
                }
            }

            if($count_error > 0){
                return 'Failed';
            }

            foreach($fh as $index => $rowHeader){
                if($header[$index] != $fh[$index]){
                    logger("'Failed', $header[$index], $fh[$index]");
                    return 'Failed';
                }
            }

            return 'Passed';
        }
    }
}