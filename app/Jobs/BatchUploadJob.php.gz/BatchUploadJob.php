<?php

namespace App\Jobs;

use App\Events\BatchUploadResult;
use App\Events\BatchFileUploadStatus;
use App\Models\FileData;
use App\Models\FileUpload;
use App\Models\TicketDataResult;
use GuzzleHttp\Client;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Support\Facades\Storage;
use Mockery\Exception;

class BatchUploadJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $file_upload;
    protected $username;
    
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($file_upload, $username)
    {
        $this->file_upload = $file_upload;
        $this->username = $username;   
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $username = $this->username;
        $file_upload = $this->file_upload;
        $this->broadcastFileUploadStatus($file_upload->status, $file_upload->id);
        
        $file =fopen(storage_path("/uploads/upload_$file_upload->id.csv"), 'r');
        
        fgetcsv($file);
        
        $content = [];
        
        $con = [];
        while($row = fgetcsv($file)){
            logger(count($content));
            logger($row[2]);
            if(count($content) < 100){
                if($row[0] == ''){
                    logger('skipped');
                    continue;
                }
                $ticket_data_result = TicketDataResult::create([
                    'file_upload_id' => $file_upload->id,
                    'sap_mru' => $row[0],
                    'sap_can' => $row[1],
                    'sap_name' => utf8_encode($row[2]),
                    'sap_address' => utf8_encode($row[3]),
                    'sap_device_number'=> $row[4],
                    'contact_number' => $row[5],
                    'concern_type' => $row[6],
                    'remarks' => $row[7],
                    'complaint_source' => $row[8],
                    'result_message' => '',
                    'status' => 'In Progress'
                ]);

                $this->broadcastUploadResult($ticket_data_result);

                $content[] = json_encode($ticket_data_result);

                if(count($content) == 99) {
                    $content = $this->sendToLWCCRM($content, $username, $file_upload);
                } else {
                    continue;
                }
            }
//            $content = $this->sendToLWCCRM($content, $username, $file_upload);
        }
        
        $this->broadcastFileUploadStatus($file_upload->status);

        if(count($content) > 1){
            $this->sendToLWCCRM($content, $username, $file_upload);
        }

        unlink((storage_path('/uploads/'). "upload_$file_upload->id.csv"));
    }
    
    protected function sendToLWCCRM($content, $username, $file_upload)
    {
        ContentSender::dispatch(json_encode($content), $username, $file_upload);
        return []; 
    }

    protected function broadcastFileUploadStatus($status)
    {
        event(new BatchFileUploadStatus($status));
    }

    protected function broadcastUploadResult($file_upload_result)
    {
        event(new BatchUploadResult($file_upload_result));
    }
}
