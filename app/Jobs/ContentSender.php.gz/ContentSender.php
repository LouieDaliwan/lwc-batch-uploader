<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use GuzzleHttp\Client;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Events\BatchFileUploadStatus;
use App\Events\BatchUploadResult;
use App\Models\FileUpload;
use App\Models\TicketDataResult;

class ContentSender implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    
    protected $content;
    protected $username;
    protected $file_upload;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($content, $username, $file_upload)
    {
        $this->content = $content;
        $this->username = $username;
        $this->file_upload = $file_upload;

    }
    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $content = $this->content;
        $content = json_decode($content, true);
        $username = $this->username;
        
        
        $file_upload = FileUpload::find($this->file_upload->id);

        $client = new Client([
            'base_uri' => config('app.lwc_crm_uri'),
        ]);

        $form_params = [
                'data' => $content,
                'username' => $username
            ];

        try{
            $promise = $client->request('POST', '/api', [
                'form_params' => $form_params
            ]);
        } catch (\Exception $e) {
            logger(date('Y-m-d H:i:s') .' '. $e->getMessage());
            
            foreach($content as $datum){
                $datum = json_decode($datum, true);
                logger($datum);
                
                $ticket = TicketDataResult::find($datum['id']);
                
                if($ticket){
                    $ticket->status = 'Failed';
                    $ticket->push();
                }

                $this->broadcastUploadResult($ticket);
            }
  
            
            $file_upload->status = 'Failed';
            $file_upload->push();     

            $this->broadcastFileUploadStatus($file_upload->status);
        }
    }

    protected function broadcastFileUploadStatus($status)
    {
        event(new BatchFileUploadStatus($status));
    }

    protected function broadcastUploadResult($file_upload_result)
    {
        event(new BatchUploadResult($file_upload_result));
    }    
}
