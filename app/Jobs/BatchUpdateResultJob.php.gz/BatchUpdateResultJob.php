<?php

namespace App\Jobs;

use App\Events\FileUploadProgress;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Events\BatchUploadResult;
use App\Events\BatchFileUploadStatus;
use App\Models\FileUpload;
use App\Models\TicketDataResult;
use Illuminate\Support\Facades\DB;

class BatchUpdateResultJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    
    protected $content;
    
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($content)
    {
        $this->content = $content;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $data = json_decode($this->content, true);
        
        $file_upload_id = '';
        foreach($data as $key => $d){
            $file_upload_id = $d['file_upload_id'];
            $ticket_data_result = TicketDataResult::find($d['id']);
            if($ticket_data_result) {
                $ticket_data_result->result_message = $d['result_message'];
                $ticket_data_result->ticket_id = $d['ticket_id'];
                $ticket_data_result->status = 'Success';
                $ticket_data_result->push();

                $this->broadcastUploadResult($ticket_data_result);
            }
        }

        $tickets = TicketDataResult::select('status', DB::raw('count(*) as count'))
            ->where('file_upload_id', $file_upload_id)
            ->groupBy('status')->get()->pluck('count','status');


        $status_count['In Progress'] = 0;
        $status_count['Success'] = 0;

        foreach($tickets as $status => $value){
            $status_count[$status] += $value;
        }
        $total_tickets = $status_count['Success'] + $status_count['In Progress'];

        $total_percent = round(($status_count['Success'] - $status_count['In Progress']) / $total_tickets * 100);

        $this->broadcastFileUploadProgress($total_percent);

        if($total_percent == 100){
            $file_upload = FileUpload::find($d['file_upload_id']);
            $file_upload->status = 'Success';
            $file_upload->push();

            $this->broadcastFileUploadStatus($file_upload->status);
        }
    }

    protected function broadcastUploadResult($file_upload_result)
    {
        event(new BatchUploadResult($file_upload_result));
    }

    protected function broadcastFileUploadStatus($status)
    {
        event(new BatchFileUploadStatus($status));
    }

    protected function broadcastFileUploadProgress($percent)
    {
        event(new FileUploadProgress($percent));
    }
}
