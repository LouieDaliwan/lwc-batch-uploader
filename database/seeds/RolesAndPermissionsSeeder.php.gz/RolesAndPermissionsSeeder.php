<?php

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RolesAndPermissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        app()['cache']->forget('spatie.permission.cache');

        // create permissions
        Permission::create(['name' => 'upload-files']);

        // create roles and assign created permissions

        $role = Role::create(['name' => 'supervisor']);
        $role->givePermissionTo('upload-files');

        $role = Role::create(['name' => 'client']);
        $role->givePermissionTo(['upload-files']);
    }
}
