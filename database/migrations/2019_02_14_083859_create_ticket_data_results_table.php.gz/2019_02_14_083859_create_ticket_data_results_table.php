<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTicketDataResultsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ticket_data_results', function (Blueprint $table) {
            $table->increments('id')->unsigned();
            $table->unsignedInteger('file_upload_id')->index();
            $table->string('sap_mru');
            $table->string('sap_can');
            $table->string('sap_name');
            $table->text('sap_address');
            $table->string('sap_device_number');
            $table->string('contact_number');
            $table->string('concern_type');
            $table->text('remarks');
            $table->text('complaint_source');
            $table->text('result_message')->nullable();
            $table->string('ticket_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ticket_data_results');
    }
}
