<?php

Route::get('/', 'HomeController@index')->middleware('auth');
Route::get('/home', 'HomeController@index')->middleware('auth');

Route::get('/batch-upload', 'BatchController@index')->name('batch-upload')->middleware('auth');
Route::post('batch-store', 'BatchController@store')->name('store')->middleware('auth');
Route::get('batch/file-uploads/{id}', 'BatchController@show')->name('show')->middleware('auth');
Route::post('batch/file-uploads/result', 'BatchController@fileUploadsResult')->middleware('auth');
Route::get('/batch/download/file-upload-result', 'BatchController@downloadFileUploadResult');
Route::get('/batch/file-upload-lists', 'BatchController@fileUploadLists')->middleware('auth');
Route::get('/get-date', 'BatchController@getDate');
Route::get('/filter/file-uploads', 'BatchController@filterFileUploads');
