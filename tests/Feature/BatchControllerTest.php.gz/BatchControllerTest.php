<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use App\User;
use Illuminate\Support\Facades\Storage;

class BatchControllerTest extends TestCase
{
    use RefreshDatabase;

    protected $fake_file;
    protected $user;

    protected function setUp()
    {
        parent::setUp();
        $this->seed('RolesAndPermissionsSeeder');
    }

    protected function signInSupervisor()
    {
        $user = factory(User::class)->create();
        $user->assignRole('supervisor');
        $this->signIn($user);
    }

    protected function signInClient()
    {
        $user = factory(User::class)->create();
        $user->assignRole('client');
        $this->signIn($user);
    }

    /** @test */
    function it_allows_lwc_supervisors_and_lwc_clients_to_uploads_the_batch_file()
    {
        $this->signInSupervisor();

        $this->fake_file = UploadedFile::fake()
        ->create('batch-create-test.csv')
        ->size(100);

        $this->post('/batch-store', [
            'file' => $this->fake_file
        ])->assertStatus(302);

        $this->signInClient();

        $this->fake_file = UploadedFile::fake()
        ->create('batch-create-test.csv')
        ->size(100);

        $this->post('/batch-store', [
            'file' => $this->fake_file
        ])->assertStatus(302);
    }

    /** @test */
    function it_requires_file_when_upload()
    {
        $this->signInSupervisor();

        $this->post('/batch-store', [
            'file' => ''
        ])->assertSessionHasErrors('file');

        $this->signInClient();

        $this->post('/batch-store', [
            'file' => ''
        ])->assertSessionHasErrors('file');
    }
}
