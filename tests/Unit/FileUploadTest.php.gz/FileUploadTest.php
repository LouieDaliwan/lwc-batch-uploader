<?php

namespace Tests\Unit;

use App\Models\FileUpload;
use Illuminate\Http\UploadedFile;
use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\User;
use Illuminate\Support\Facades\Storage;

class FileUploadTest extends TestCase
{
    use RefreshDatabase;

    protected $user;

    protected function setUp()
    {
        parent::setUp();

        $this->user = factory(User::class)->create();
        $this->signIn($this->user);
    }

    /** @test */
    function it_saves_the_filename_and_uploader_into_database_and_store_in_storage()
    {
        $upload_file = UploadedFile::fake()->create('batch.csv');

        FileUpload::create([
           'filename' => $upload_file->getFilename(),
           'uploader_name' => $this->user->name,
           'status' => 'Processing'
        ]);

        $this->assertDatabaseHas('file_uploads', [
           'filename' => $upload_file->getFilename(),
           'uploader_name' => $this->user->name,
           'status' => 'Processing'
        ]);
    }
}
