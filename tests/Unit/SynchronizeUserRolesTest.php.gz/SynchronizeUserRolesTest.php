<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Listeners\SynchronizeUserRoles;
use Spatie\Permission\Models\Role;
use SocialiteProviders\Teleserv\Events\UserLoggedIn;
use App\User;

class SynchronizeUserRolesTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    function it_saves_the_erm_credentials()
    {
        Role::create(['name' => 'supervisor']);
        Role::create(['name' => 'auditor']);
        
        $erm_user = (object) ['first_name' => 'Jane', 'last_name' => 'Doe', 'roles' => ['ITHEAD'], 'employee_code' => '094949'];
        $user = factory(User::class)->create(['email' => 'janedoe@test.com']);

        $sync = new SynchronizeUserRoles();

        $sync->handle(new UserLoggedIn($user, $erm_user));

        $this->assertDatabaseHas('users', [
            'first_name' => 'Jane',
            'last_name' => 'Doe',
            'email' => 'janedoe@test.com',
            'employee_code' => '094949'
        ]);
    }

    /** @test */
    function it_will_apply_the_supervisor_role_for_authorized_erm_role()
    {
        Role::create(['name' => 'supervisor']);
        Role::create(['name' => 'client']);

        $user = factory(User::class)->create();
        $sync = new SynchronizeUserRoles();
        
        $sync->applyRoleMap($user, collect(['ITHEAD', 'superuser', 'JPRMR']));
        $this->assertTrue($user->fresh()->hasRole('supervisor'));
    }

    /** @test **/
    function it_will_apply_the_client_role_for_authorized_erm_roles()
    {
        Role::create(['name' => 'client']);
        Role::create(['name' => 'supervisor']);
        $sync = new SynchronizeUserRoles();

        $user = factory(User::class)->create();
        $sync->applyRoleMap($user, collect(['lwc_client']));
        $this->assertTrue($user->fresh()->hasRole('client'));
    }

    /** @test **/
    function it_will_not_apply_the_supervisor_and_client_role_for_unauthorized_erm_roles()
    {
        Role::create(['name' => 'supervisor']);
        Role::create(['name' => 'client']);

        $user = factory(User::class)->create();

        $sync = new SynchronizeUserRoles();

        $sync->applyRoleMap($user, collect(['lwc_agent', 'TTSO']));

        $this->assertFalse($user->hasRole('supervisor'));
        $this->assertFalse($user->hasRole('client'));
    }

    /** @test **/
    function it_will_not_apply_the_supervisor_or_client_role_to_user_have_already_assigned()
    {
        Role::create(['name' => 'supervisor']);
        Role::create(['name' => 'client']);

        $user = factory(User::class)->create();
        $user->assignRole(['supervisor', 'client']);

        $sync = new SynchronizeUserRoles();

        $sync->applyRoleMap($user, collect(['lwc_supervisor', 'ITHEAD', 'lwc_client',]));

        $this->assertEquals(2, count($user->getRoleNames()));
    }
}