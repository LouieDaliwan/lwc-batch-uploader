<template>
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-4">
				<div class="card">
					<div class="card-header">Files</div>
					<div class="card-body">
						<table class="table">
							<thead>
								<th>Name</th>
								<th>Status</th>
								<th></th>
							</thead>
							<tbody>
								<tr>

									<td><button class="btn btn-primary"  @click="getFileDataResult(upload.id)">{{ upload.filename }}</button>
									</td>
									<td>{{ upload_status }}</td>
									<td v-if="upload_status === 'Success'">
										<button class="btn btn-success" type="button" @click.prevent="downloadFile(upload.id)">
											<span class="glyphicon glyphicon-download"></span>Download 
										</button>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div class="progress"  v-if="upload_status === 'In Progress'"  style="width: 100%">
						<div class="progress-bar bg-success progress-bar-striped progress-bar-animated" role="progressbar" :style="{width: percentage + '%'}" :aria-valuenow="percentage" aria-valuemin="0" aria-valuemax="100">
							{{ percentage }}%
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-8">
				<div class="card">
					<div class="card-header">List of data results</div>
					<div class="card-body" v-if="upload_id != ''" style="overflow-x: scroll; overflow-y: scroll; height: 700px;">
						<upload-content-result :fileUploadId="upload_id"></upload-content-result>
					</div>
				</div>
			</div>   
		</div>
	</div>
</template>


<script>
	import UploadContentResult from '../components/UploadContentResult.vue';

    export default {
		components : { UploadContentResult},
		props: ['upload'],
		data() {
			return {
				upload_id: '',
				upload_status: '',
			    percentage: 0,

			}
		},
		mounted(){
			this.getFileDataResult(this.upload.id);
		
			this.file_upload_id = this.fileUploadId;
			this.upload_status = this.upload.status;
			
			Echo.channel("App.Models.FileUpload").listen(
				"BatchFileUploadStatus", e => {
					this.upload_status = e.status;
				}
			);

			Echo.channel("App.FileUpload.Progress").listen(
				"FileUploadProgress", e => {
					console.log(e);
					this.percentage = e.percent
			  }
			)
		},
		methods: {
			getFileDataResult(id){
					this.upload_id = id;
			},
			downloadFile(id){
					window.location = `/batch/download/file-upload-result?id=${id}`;
			}
		}
	}
</script>