<template>
    <table class="table table-condensed table-hover" v-if="paginator">
        <thead>
            <tr class="tr_title">
                <th>Filename</th>
                <th>Uploader Name</th>
                <th>Status</th>
                <th colspan="2">Upload At</th>
            </tr>
        </thead>
        <tbody>
            <tr v-for="row in paginator.data">
                <td v-text="row.filename"></td>
                <td v-text="row.uploader_name"></td>
                <td v-text="row.status"></td>
                <td v-text="row.created_at"></td>
                <td><button type="button" class="btn btn-success" @click="downloadFile(row.id)">Download</button></td>
            </tr>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="4">
                <div class="level">
                    <div class="flex">
                        Total : <span class="badge">{{this.paginator.total}}</span>
                        Page {{this.paginator.current_page}}
                        of {{this.paginator.last_page}}</div>
                    <div class="btn-group" role="group">
                        <button type="button"
                                :disabled="this.paginator.prev_page_url === null"
                                @click="prevPage"
                                class="btn btn-sm btn-default">
                            Previous
                        </button>
                        <button type="button"
                                :disabled="this.paginator.next_page_url === null"
                                @click="nextPage"
                                class="btn btn-sm btn-default">
                            Next
                        </button>
                    </div>

                </div>
            </td>
        </tr>
        </tfoot>
    </table>
</template>


<script>
    export default {
        props: ['data'],

        watch: {
            data(newVal) {
                this.paginator = newVal;
                console.log(this.paginator);
            }
        },

        data() {
            return {
                columnCount: _.keys(this.headers).length + 1,
                paginator: this.data,
            }
        },

        methods: {
            nextPage() {
                axios.get(this.paginator.next_page_url)
                    .then(({data}) => {
                    	this.paginator = data.files
                    });
            },

            prevPage() {
                axios.get(this.paginator.prev_page_url)
                .then(({data}) => {
                    this.paginator = data.files
                });
            },
            get(row, key) {
                return _.get(row, key);
            },

            downloadFile(id)
            {
                window.location = `/batch/download/file-upload-result?id=${id}`;
            }
        }
    }
</script>