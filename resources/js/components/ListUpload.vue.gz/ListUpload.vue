<template>
    <div class="row">
            <div class="col-3">
                <div class="card">
                    <div class="card-header">Filter Date</div>
                    <div class="card-body">
                        <form>
                            <div class="form-group">
                                <label for="from">From</label>
                                <input type="date" id="from" name="from" class="form-control"  v-model="date_from">
                            </div>

                            <div class="form-group">
                                <label for="to">From</label>
                                <input type="date" id="to" name="to" class="form-control" :min="date_from" :max="date_to" v-model="date_to">
                            </div>

                            <div class="form-group">
                                <label for="uploader">Uploader Name</label>
                                <input type="name" id="uploader" name="uploader"  class="form-control" v-model="uploader_name">
                            </div>

                            <button type="submit" class="btn btn-primary" @click.prevent="filterDates()">Filter</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col">
                <div class="card">
                    <div class="card-header">File Uploads</div>
                    <div class="card-body">
                        <data-table v-if="files != null" :data="files"></data-table>
                    </div>
                </div>
            </div>
        </div>
</template>

<script>
    import DataTable from '../components/DataTable.vue'; 

    export default{
        components :{ DataTable },
        props: ['from', 'to'],

        data(){
            return {
                date_from: this.from,
                date_to: this.to,
                files: null,
                uploader_name: '',
            }
        },
        mounted(){
            this.filterDates();
        },
        watch: {
            date_from(newValue){
                this.getDate();
            }
        },
        methods: {
            getDate(){
                let url = `/get-date?from=${this.date_from}`;

                axios.get(url).then(({data})=> {
                    console.log(data);
                    this.date_to = data.to
                });
            },

            filterDates()
            {
                let url = `/filter/file-uploads?from=${this.date_from}&to=${this.date_to}&uploader=${this.uploader_name}`

                this.files = null;
                axios.get(url).then(({data}) => {
                    this.files = data.files ;
                });
            },

            downloadFile(id)
            {
                window.location = `/batch/download/file-upload-result?id=${id}`;
            }
        }
    }
</script>