<template>
  <div>
      <span>Record Count: {{ events.length }}</span>
      <table class="table table-default">
          <thead>
              <tr>
                  <th>SAP_MRU</th>
                  <th>SAP_CAN</th>
                  <th>SAP_NAME</th>
                  <th>SAP_ADDRESS</th>
                  <th>SAP_DEVICE_NUMBER</th>
                  <th>CONTACT_NUMBER</th>
                  <th>CONCERN_TYPE</th>
                  <th>REMARKS</th>
                  <th>COMPLAINT_SOURCE</th>
                  <th>RESULT_MESSAGE</th>
                  <th>TICKET_ID</th>
                  <th>Status</th>
              </tr>
          </thead>
          <tbody>
              <tr v-for="event in events">
                  <td>{{ event['sap_mru'] }}</td>
                  <td>{{ event['sap_can']}}</td>
                  <td>{{ event['sap_name']}}</td>
                  <td>{{ event['sap_address']}}</td>
                  <td>{{ event['sap_device_number']}}</td>
                  <td>{{ event['contact_number']}}</td>
                  <td>{{ event['concern_type']}}</td>
                  <td>{{ event['remarks']}}</td>
                  <td>{{ event['complaint_source']}}</td>
                  <td>{{ event['result_message']}}</td>
                  <td>{{ event['ticket_id']}}</td>
                  <td>{{ event['status']}}</td>
              </tr>
          </tbody>
      </table>
  </div>
</template>

<script>
export default {
    props: ["fileUploadId", "fileResult"],
    data() {
        return {
          events: [],
          file_upload_id: "",
          data_test: null,
        };
    },
    watch: {
        fileUploadId: function(newVal) {
            this.file_upload_id = newVal;
            this.getUploadFileResults();
        }
    },

    mounted() {
        this.file_upload_id = this.fileUploadId;
        this.getUploadFileResults();


        Echo.channel("App.Models.TicketDataResult").listen(
            "BatchUploadResult", e => {
            if(!_.isEmpty(this.events)){
                let event = _.find(this.events, ['id', e.fileUploadResult.id]);
                if(event){
                      event.result_message = e.fileUploadResult.result_message;
                      event.ticket_id = e.fileUploadResult.ticket_id;
                      event.status = e.fileUploadResult.status;
                } else {
                      this.events.push(e.fileUploadResult);
                }
            } else {
			  this.events.push(e.fileUploadResult);
            }
        });
    },
    methods: {
        getUploadFileResults() {
            axios.post("/batch/file-uploads/result", {
                file_upload_id: this.file_upload_id
            }).then(({ data }) => {
                this.events = data;
            });
        }
    }
};
</script>