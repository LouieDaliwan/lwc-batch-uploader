@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <list-upload :from="'{{ $from->format('Y-m-d') }}'"
                     :to="'{{ $to->format('Y-m-d') }}'"
        ></list-upload>
    </div>
@endsection