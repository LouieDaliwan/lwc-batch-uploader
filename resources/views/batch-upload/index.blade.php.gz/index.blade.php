@extends('layouts.app')

@section('content')
    <div class="container">
        @if(session('Error'))
            <div class="row justify-content-center">
                <div class="alert alert-danger">
                    <p >
                        {{ session('Error')}}
                    </p>
                </div>
            </div>
        @endif
        
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card card-default">
                    <div class="card-header">Batch file upload</div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('store') }}" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group">
                                <label for="upload_batch_file">Upload Batch File</label>
                                <input id="upload_batch_file" type="file" name="file" class="form-control-file" accept="text/csv" required><br>
                                <label for="username">Username</label>
                                <input type="text" id="username" name="username" value="{{ auth()->user()->username }}" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-success">Upload</button>
                        </form>
                    </div>
                </div>
            </div>    
        </div>
    </div>
@stop