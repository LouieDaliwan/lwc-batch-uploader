@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <upload-progress :upload="{{$file_upload}}"></upload-progress>
    </div>
    
    
@endsection